class YuzuTeaError(Exception):
    """Base exception for YuzuTea package"""
    pass